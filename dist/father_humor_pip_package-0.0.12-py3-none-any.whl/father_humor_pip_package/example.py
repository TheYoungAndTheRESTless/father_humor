def printfunc():
    print("hello world")