def help_dad():
    """


   """

    print("Help dad will show you all available options on how to use this package")


help_dad()
